import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

df = pd.read_csv('sales_data_sample.csv', encoding='latin1')
X = df.select_dtypes(include='number').drop(
    columns=['ORDERNUMBER', 'ORDERLINENUMBER', 'QTR_ID', 'MONTH_ID', 'YEAR_ID'], errors='ignore'
)
X = StandardScaler().fit_transform(X)

inertia = []
for k in range(1, 11):
    model = KMeans(n_clusters=k, random_state=42, n_init=10)
    model.fit(X)
    inertia.append(model.inertia_)

plt.plot(range(1, 11), inertia, marker='o')
plt.xlabel('Number of clusters')
plt.ylabel('Inertia')
plt.title('Elbow Method')
plt.show()

# Choose the elbow from the graph (3 is a simple starting choice).
kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
df['Cluster'] = kmeans.fit_predict(X)
print(df['Cluster'].value_counts())
