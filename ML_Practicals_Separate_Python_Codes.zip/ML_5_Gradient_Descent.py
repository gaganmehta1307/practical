x = 2
learning_rate = 0.1

for i in range(100):
    gradient = 2 * (x + 3)
    x = x - learning_rate * gradient

print('Local minimum x:', x)
print('Minimum y:', (x + 3) ** 2)
