MACHINE LEARNING PRACTICALS — PYTHON SOURCE CODE
================================================

Each practical is provided as a separate .py file:

1. ML_1_Bank_Churn_Neural_Network.py
2. ML_2_Email_Spam_KNN_SVM.py
3. ML_3_Diabetes_KNN.py
4. ML_4_Sales_KMeans_Elbow.py
5. ML_5_Gradient_Descent.py

REQUIREMENTS
------------
Install the required packages:
    pip install pandas scikit-learn matplotlib

DATASETS
--------
Keep the following CSV files in the same folder as the corresponding Python
script (or update the file path in the script):

- Practical 1: Churn_Modelling.csv
- Practical 2: emails.csv
- Practical 3: diabetes.csv
- Practical 4: sales_data_sample.csv
- Practical 5: No dataset required.

RUN
---
Open a terminal in this folder and run, for example:
    python ML_1_Bank_Churn_Neural_Network.py

The scripts contain the code cells from the supplied Jupyter notebooks,
combined in order into individual Python files.
