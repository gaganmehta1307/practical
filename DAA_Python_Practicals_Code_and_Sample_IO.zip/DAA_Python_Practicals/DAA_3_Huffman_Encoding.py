# DAA-3: Huffman Encoding Using Greedy Strategy
import heapq

class Node:
    def __init__(self, char, freq):
        self.char = char
        self.freq = freq
        self.left = None
        self.right = None


def huffman_encoding(chars, frequencies):
    # The counter provides deterministic tie-breaking for equal frequencies.
    heap = []
    counter = 0
    for char, freq in zip(chars, frequencies):
        heapq.heappush(heap, (freq, counter, Node(char, freq)))
        counter += 1

    if not heap:
        return

    while len(heap) > 1:
        _, _, left = heapq.heappop(heap)
        _, _, right = heapq.heappop(heap)
        parent = Node(None, left.freq + right.freq)
        parent.left = left
        parent.right = right
        heapq.heappush(heap, (parent.freq, counter, parent))
        counter += 1

    def generate_codes(node, code=""):
        if node.char is not None:
            print(node.char, ":", code if code else "0")
            return
        generate_codes(node.left, code + "0")
        generate_codes(node.right, code + "1")

    print("Huffman Codes:")
    generate_codes(heap[0][2])

n = int(input("Enter number of characters: "))
chars = []
frequencies = []
for _ in range(n):
    char, freq = input("Enter character and frequency: ").split()
    chars.append(char)
    frequencies.append(int(freq))

huffman_encoding(chars, frequencies)
