# DAA-4: Fractional Knapsack Using Greedy Method

def fractional_knapsack(items, capacity):
    items.sort(key=lambda item: item[1] / item[0], reverse=True)
    total_profit = 0.0

    for weight, profit in items:
        if capacity <= 0:
            break
        if weight <= capacity:
            total_profit += profit
            capacity -= weight
        else:
            fraction = capacity / weight
            total_profit += profit * fraction
            capacity = 0

    return total_profit

n = int(input("Enter number of items: "))
items = []
for _ in range(n):
    weight, profit = map(float, input("Enter weight and profit: ").split())
    items.append((weight, profit))

capacity = float(input("Enter knapsack capacity: "))
print("Maximum Profit:", round(fractional_knapsack(items, capacity), 2))
