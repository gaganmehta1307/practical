# DAA-5: 0-1 Knapsack Using Dynamic Programming

def knapsack(weights, profits, capacity):
    n = len(weights)
    dp = [[0 for _ in range(capacity + 1)] for _ in range(n + 1)]

    for i in range(1, n + 1):
        for current_capacity in range(capacity + 1):
            if weights[i - 1] <= current_capacity:
                dp[i][current_capacity] = max(
                    profits[i - 1] + dp[i - 1][current_capacity - weights[i - 1]],
                    dp[i - 1][current_capacity]
                )
            else:
                dp[i][current_capacity] = dp[i - 1][current_capacity]

    return dp[n][capacity]

n = int(input("Enter number of items: "))
weights = []
profits = []
for _ in range(n):
    weight, profit = map(int, input("Enter weight and profit: ").split())
    weights.append(weight)
    profits.append(profit)

capacity = int(input("Enter knapsack capacity: "))
print("Maximum Profit:", knapsack(weights, profits, capacity))
