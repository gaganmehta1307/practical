# DAA-1: Fibonacci Series (Recursive and Non-Recursive)
n = int(input("Enter number of terms: "))

# Non-recursive (iterative) method
a, b = 0, 1
print("Non-Recursive:", end=" ")
for _ in range(n):
    print(a, end=" ")
    a, b = b, a + b

# Recursive method
def fibonacci(num):
    if num <= 1:
        return num
    return fibonacci(num - 1) + fibonacci(num - 2)

print("\nRecursive:", end=" ")
for i in range(n):
    print(fibonacci(i), end=" ")
print()
