# DAA-2: Job Sequencing with Deadlines Using Greedy Method

def job_sequencing(jobs):
    jobs.sort(key=lambda job: job[2], reverse=True)
    if not jobs:
        print("Scheduled Jobs: []")
        print("Maximum Profit: 0")
        return

    max_deadline = max(job[1] for job in jobs)
    slots = [None] * max_deadline
    total_profit = 0

    for job_id, deadline, profit in jobs:
        for slot in range(min(deadline, max_deadline) - 1, -1, -1):
            if slots[slot] is None:
                slots[slot] = job_id
                total_profit += profit
                break

    print("Scheduled Jobs:", [job for job in slots if job is not None])
    print("Maximum Profit:", total_profit)

n = int(input("Enter number of jobs: "))
jobs = []
for _ in range(n):
    job_id, deadline, profit = input("Enter job ID, deadline and profit: ").split()
    jobs.append((job_id, int(deadline), int(profit)))

job_sequencing(jobs)
