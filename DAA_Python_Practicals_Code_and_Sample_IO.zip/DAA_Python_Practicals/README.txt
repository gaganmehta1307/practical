DAA PYTHON PRACTICALS
====================

This folder contains five separate Python 3 programs. Each program has a
matching sample input and sample output text file.

FILES
-----
DAA_1_Fibonacci.py
DAA_2_Job_Sequencing.py
DAA_3_Huffman_Encoding.py
DAA_4_Fractional_Knapsack.py
DAA_5_Zero_One_Knapsack.py

SAMPLE FILES
------------
Each practical has two corresponding files:
  DAA_X_Sample_Input.txt
  DAA_X_Sample_Output.txt

HOW TO RUN
----------
1. Install Python 3.
2. Open a terminal or command prompt in this folder.
3. Run the required program, for example:
     python DAA_1_Fibonacci.py
4. Enter the values shown in that practical's Sample_Input file.
5. Compare the result with the Sample_Output file.

Huffman note: Huffman codes can vary when frequencies are tied or when
left/right branches are assigned differently. The supplied sample uses
unique frequencies and produces the output included in its sample file.
