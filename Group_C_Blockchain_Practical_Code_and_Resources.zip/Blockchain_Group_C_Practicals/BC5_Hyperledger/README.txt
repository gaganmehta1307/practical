BC-5 SETUP: HYPERLEDGER FABRIC TEST NETWORK
Prerequisites: Linux/macOS or Windows with WSL2; Docker; Git; curl; Node.js; Python 3;
Fabric samples, binaries and Docker images installed using the official guide:
https://hyperledger-fabric.readthedocs.io/en/latest/install.html

1. Obtain fabric-samples and Fabric binaries using the official install guide.
2. Put this BC5_Hyperledger directory at a path accessible from fabric-samples/test-network.
3. In fabric-samples/test-network:
   ./network.sh down
   ./network.sh up createChannel
4. Deploy JavaScript chaincode (adjust relative path if you placed the folder elsewhere):
   ./network.sh deployCC -ccn business -ccp ../../BC5_Hyperledger -ccl javascript
5. Configure peer CLI environment for Org1 using scripts included in your downloaded release.
   Common setup from test-network:
   export PATH=${PWD}/../bin:$PATH
   export FABRIC_CFG_PATH=${PWD}/../config/
   source ./scripts/envVar.sh
   setGlobals 1
6. Invoke/query:
   peer chaincode invoke -C mychannel -n business -c '{"function":"RegisterBusiness","Args":["BIZ001","ABC Traders","Wholesale","Nashik"]}'
   peer chaincode query -C mychannel -n business -c '{"function":"ReadBusiness","Args":["BIZ001"]}'
   peer chaincode invoke -C mychannel -n business -c '{"function":"UpdateStatus","Args":["BIZ001","INACTIVE"]}'
   peer chaincode query -C mychannel -n business -c '{"function":"GetAllBusinesses","Args":[]}'
7. Optional Python CLI wrapper, from a terminal with peer and Org1 environment configured:
   python ../../BC5_Hyperledger/fabric_client.py register BIZ001 "ABC Traders" Wholesale Nashik
   python ../../BC5_Hyperledger/fabric_client.py read BIZ001
   python ../../BC5_Hyperledger/fabric_client.py status BIZ001 INACTIVE
   python ../../BC5_Hyperledger/fabric_client.py all
8. Stop and clean the local network: ./network.sh down

Fabric v2.4+ official Gateway client APIs are Go, Node.js and Java. This practical uses
JavaScript chaincode and a Python subprocess wrapper for the peer CLI; it does not claim
that a current official Python Gateway SDK exists.
