'use strict';
const { Contract } = require('fabric-contract-api');

class BusinessNetworkContract extends Contract {
    async RegisterBusiness(ctx, businessId, businessName, businessType, city) {
        if (!businessId || !businessName) throw new Error('businessId and businessName are required');
        const existing = await ctx.stub.getState(businessId);
        if (existing && existing.length > 0) throw new Error(`Business ${businessId} already exists`);
        const record = { docType: 'business', businessId, businessName, businessType, city, status: 'ACTIVE' };
        await ctx.stub.putState(businessId, Buffer.from(JSON.stringify(record)));
        return JSON.stringify(record);
    }

    async ReadBusiness(ctx, businessId) {
        const data = await ctx.stub.getState(businessId);
        if (!data || data.length === 0) throw new Error(`Business ${businessId} does not exist`);
        return data.toString();
    }

    async UpdateStatus(ctx, businessId, newStatus) {
        const data = await ctx.stub.getState(businessId);
        if (!data || data.length === 0) throw new Error(`Business ${businessId} does not exist`);
        const record = JSON.parse(data.toString());
        record.status = newStatus;
        await ctx.stub.putState(businessId, Buffer.from(JSON.stringify(record)));
        return JSON.stringify(record);
    }

    async GetAllBusinesses(ctx) {
        const iterator = await ctx.stub.getStateByRange('', '');
        const results = [];
        let item = await iterator.next();
        while (!item.done) {
            try {
                const record = JSON.parse(item.value.value.toString('utf8'));
                if (record.docType === 'business') results.push(record);
            } catch (err) { /* Ignore unrelated ledger values in this demo. */ }
            item = await iterator.next();
        }
        await iterator.close();
        return JSON.stringify(results);
    }
}
module.exports = BusinessNetworkContract;
