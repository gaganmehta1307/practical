"""
Python helper that calls the Hyperledger Fabric peer CLI.
Run from a terminal where peer CLI and Org1 environment variables are configured.
"""
import json, os, subprocess, sys
CHANNEL = "mychannel"
CHAINCODE = "business"

def main():
    if len(sys.argv) < 2:
        print("register BIZ001 'ABC Traders' Wholesale Nashik")
        print("read BIZ001 | status BIZ001 INACTIVE | all")
        return
    action = sys.argv[1].lower()
    if action == "register" and len(sys.argv) == 6:
        fn, args, mode = "RegisterBusiness", sys.argv[2:6], "invoke"
    elif action == "read" and len(sys.argv) == 3:
        fn, args, mode = "ReadBusiness", [sys.argv[2]], "query"
    elif action == "status" and len(sys.argv) == 4:
        fn, args, mode = "UpdateStatus", sys.argv[2:4], "invoke"
    elif action == "all" and len(sys.argv) == 2:
        fn, args, mode = "GetAllBusinesses", [], "query"
    else:
        raise SystemExit("Invalid arguments. Run without arguments for usage.")
    payload = json.dumps({"function": fn, "Args": args})
    command = ["peer", "chaincode", mode, "-C", CHANNEL, "-n", CHAINCODE, "-c", payload]
    print("$", " ".join(command))
    subprocess.run(command, check=True, env=os.environ.copy())

if __name__ == "__main__":
    main()
