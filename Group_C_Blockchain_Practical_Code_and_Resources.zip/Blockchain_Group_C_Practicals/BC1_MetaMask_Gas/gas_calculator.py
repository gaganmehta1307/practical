from decimal import Decimal, getcontext
getcontext().prec = 28

def calculate_fee(gas_used, gas_price_gwei):
    return Decimal(int(gas_used)) * Decimal(str(gas_price_gwei)) / Decimal(10**9)

print("ETH Transaction Gas Fee Calculator")
gas_used = input("Enter gas used (example 21000): ")
gas_price = input("Enter gas price in Gwei (example 20): ")
fee = calculate_fee(gas_used, gas_price)
print(f"Estimated transaction fee: {fee:.12f} ETH")
print("Formula: Fee (ETH) = Gas used x Gas price (Gwei) / 1,000,000,000")
