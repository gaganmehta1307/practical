BC-1 SETUP
1. Install MetaMask only from https://metamask.io/ and its official browser-store link.
2. Create a wallet and store the Secret Recovery Phrase offline. Never share it.
3. Select Ethereum Sepolia test network for learning; do not use real funds.
4. Obtain test ETH from a reputable Sepolia faucet if available.
5. Send a small test transaction to another test account.
6. Open transaction details / block explorer and note gasUsed and effectiveGasPrice.
7. Run: python gas_calculator.py
8. Compare the calculator with the actual transaction receipt.
Safety: A seed phrase/private key gives control of funds. No support person needs it.
