// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// Educational testnet example: separate Ether balance for each customer address.
contract BankAccount {
    mapping(address => uint256) private balances;
    event Deposited(address indexed customer, uint256 amount);
    event Withdrawn(address indexed customer, uint256 amount);

    function deposit() external payable {
        require(msg.value > 0, "Deposit must be greater than zero");
        balances[msg.sender] += msg.value;
        emit Deposited(msg.sender, msg.value);
    }

    function withdraw(uint256 amountWei) external {
        require(amountWei > 0, "Amount must be greater than zero");
        require(balances[msg.sender] >= amountWei, "Insufficient balance");
        balances[msg.sender] -= amountWei;
        (bool success, ) = payable(msg.sender).call{value: amountWei}("");
        require(success, "Transfer failed");
        emit Withdrawn(msg.sender, amountWei);
    }

    function showBalance() external view returns (uint256) {
        return balances[msg.sender];
    }
}
