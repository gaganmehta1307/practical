BC-3 EXECUTION
1. Open https://remix.ethereum.org/ and create BankAccount.sol.
2. Paste the supplied Solidity code.
3. Compile using Solidity 0.8.20 or a compatible 0.8.x compiler.
4. Deploy & Run > Environment > Remix VM. Select BankAccount and Deploy.
5. Deposit: enter 1 in VALUE, select Ether, then call deposit().
6. Call showBalance(); 1 ETH should be 1000000000000000000 wei.
7. Withdraw 0.1 ETH by calling withdraw(100000000000000000).
8. Call showBalance(); expected balance is 900000000000000000 wei.
9. Optional: connect MetaMask to Sepolia, choose Injected Provider and deploy.
This contract is for education only, not a production banking application.
