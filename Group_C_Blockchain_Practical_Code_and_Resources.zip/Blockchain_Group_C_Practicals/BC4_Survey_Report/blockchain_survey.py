blockchains = {
    "Public": ("Open participation", "Bitcoin payments; Ethereum smart contracts"),
    "Private": ("Controlled by one organization", "Internal audit trails; enterprise records"),
    "Consortium": ("Governed by multiple organizations", "Inter-bank settlement; trade finance"),
    "Hybrid": ("Public verification with private data", "Healthcare consent; enterprise identity")
}
print("TYPES OF BLOCKCHAINS AND USE CASES")
for kind, (feature, uses) in blockchains.items():
    print(f"\n{kind} Blockchain")
    print("  Characteristic:", feature)
    print("  Example use cases:", uses)
