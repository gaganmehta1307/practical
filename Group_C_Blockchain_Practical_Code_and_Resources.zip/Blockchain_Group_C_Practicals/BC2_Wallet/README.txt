BC-2 SETUP
1. Install MetaMask from https://metamask.io/.
2. Choose Create a new wallet and set a strong password.
3. Back up the Secret Recovery Phrase offline, in the correct order.
4. Confirm the phrase in MetaMask. Do not photograph, email or share it.
5. Select Sepolia test network for practice.
6. Copy your public address and receive test ETH from a faucet.
7. Send a small test amount to a second test address and inspect the transaction.
Optional Python demo:
  python -m pip install eth-account
  python create_wallet.py
The script prints a disposable private key. Never use it for a funded mainnet wallet.
