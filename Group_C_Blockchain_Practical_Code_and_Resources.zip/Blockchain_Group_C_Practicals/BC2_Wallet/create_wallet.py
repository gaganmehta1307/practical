"""
Optional local Ethereum account demo.
Install: python -m pip install eth-account
Run: python create_wallet.py
Use only a disposable test account. Never fund it with real cryptocurrency.
"""
from eth_account import Account
acct = Account.create()
print("New Ethereum account created.")
print("Public address:", acct.address)
print("Private key (NEVER SHARE; demo only):", acct.key.hex())
print("An address is public; a private key controls the account.")
